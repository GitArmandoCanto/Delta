sap.ui.define([
	"deltanmsp/delta_app/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
